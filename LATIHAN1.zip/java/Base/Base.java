//Base.java
package Base;
public class Base{
protected void amethod(){
System.out.println("amethod");
}//End of amethod
}//End of class base
