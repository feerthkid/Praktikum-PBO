package Class1;
//Class1.java
import Base.*;

public class Class1 extends Base {
    public static void main(String argv[]) {
        Class1 c = new Class1();
        c.amethod();
    }//End of main
}//End of Class1