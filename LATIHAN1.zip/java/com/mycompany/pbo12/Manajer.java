package com.mycompany.pbo12;

public class Manajer extends Pegawai {
    public String departemen;
    
    public void IsiData(String n, String d) {
    nama=n;
    departemen=d;
    }
}