/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.pbo12;

/**
 *
 * @author nasya
 */
public class PBO12 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
