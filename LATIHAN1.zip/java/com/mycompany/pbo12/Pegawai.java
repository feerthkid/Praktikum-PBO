package com.mycompany.pbo12;

public class Pegawai {   
    protected String nama;
    public double gaji;
}
